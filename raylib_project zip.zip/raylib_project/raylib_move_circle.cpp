#include "raylib.h"
#include "raymath.h"
#include <cmath>

enum ShapeType { CIRCLE, SQUARE, TRIANGLE, STAR, PENTAGON };

int main() {
    const int screenWidth = 800;
    const int screenHeight = 600;
    InitWindow(screenWidth, screenHeight, "Raylib Shape Inertia + Bounce");

    Vector2 shapePos = {400, 300};
    Vector2 velocity = {0, 0};
    Vector2 dragOffset = {0, 0};

    float shapeRadius = 60.0f;
    float speed = 5.0f;

    ShapeType currentShape = CIRCLE;
    Color shapeColor = RED;

    int lastClickTime = 0;
    const int doubleClickThreshold = 300; // ms
    bool isDragging = false;
    Vector2 lastMousePos = {0, 0};
    Vector2 mouseSpeed = {0, 0};

    SetTargetFPS(60);

    while (!WindowShouldClose()) {
        Vector2 mousePos = GetMousePosition();
        Vector2 mouseDelta = Vector2Subtract(mousePos, lastMousePos);
        lastMousePos = mousePos;

        bool mouseOverShape = false;
        if (currentShape == CIRCLE) {
            mouseOverShape = CheckCollisionPointCircle(mousePos, shapePos, shapeRadius);
        } else {
            Rectangle bounds = {shapePos.x - shapeRadius, shapePos.y - shapeRadius, shapeRadius * 2, shapeRadius * 2};
            mouseOverShape = CheckCollisionPointRec(mousePos, bounds);
        }

        // Double-click to change shape
        if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && mouseOverShape) {
            int now = GetTime() * 1000;
            if (now - lastClickTime < doubleClickThreshold) {
                currentShape = static_cast<ShapeType>((currentShape + 1) % 5);
            }
            lastClickTime = now;
            isDragging = true;
            dragOffset = Vector2Subtract(shapePos, mousePos);
            velocity = {0, 0}; // Stop current motion while dragging
        }

        if (IsMouseButtonReleased(MOUSE_LEFT_BUTTON)) {
            isDragging = false;
            velocity = mouseDelta; // Capture inertia
        }

        // Drag
        if (isDragging && IsMouseButtonDown(MOUSE_LEFT_BUTTON)) {
            shapePos = Vector2Add(mousePos, dragOffset);
        }

        // Keyboard movement
        if (IsKeyDown(KEY_RIGHT) || IsKeyDown(KEY_D)) velocity.x = speed;
        if (IsKeyDown(KEY_LEFT) || IsKeyDown(KEY_A))  velocity.x = -speed;
        if (IsKeyDown(KEY_DOWN) || IsKeyDown(KEY_S))  velocity.y = speed;
        if (IsKeyDown(KEY_UP) || IsKeyDown(KEY_W))    velocity.y = -speed;

        // Update position with inertia
        shapePos = Vector2Add(shapePos, velocity);

        // Bounce off edges
        bool bounced = false;
        if (shapePos.x <= shapeRadius) {
            shapePos.x = shapeRadius;
            velocity.x *= -1;
            bounced = true;
        }
        if (shapePos.x >= screenWidth - shapeRadius) {
            shapePos.x = screenWidth - shapeRadius;
            velocity.x *= -1;
            bounced = true;
        }
        if (shapePos.y <= shapeRadius) {
            shapePos.y = shapeRadius;
            velocity.y *= -1;
            bounced = true;
        }
        if (shapePos.y >= screenHeight - shapeRadius) {
            shapePos.y = screenHeight - shapeRadius;
            velocity.y *= -1;
            bounced = true;
        }

        // Bounce effect: flash color
        if (bounced) {
            shapeColor = ColorFromHSV(GetRandomValue(0, 360), 0.8f, 0.9f);
        }

        // Apply damping to inertia
        velocity = Vector2Scale(velocity, 0.98f);

        // DRAW
        BeginDrawing();
        ClearBackground(RAYWHITE);

        switch (currentShape) {
            case CIRCLE:
                DrawCircleV(shapePos, shapeRadius, shapeColor);
                break;
            case SQUARE:
                DrawRectangleV((Vector2){shapePos.x - shapeRadius, shapePos.y - shapeRadius}, (Vector2){shapeRadius * 2, shapeRadius * 2}, shapeColor);
                break;
            case TRIANGLE: {
                Vector2 p1 = {shapePos.x, shapePos.y - shapeRadius};
                Vector2 p2 = {shapePos.x - shapeRadius, shapePos.y + shapeRadius};
                Vector2 p3 = {shapePos.x + shapeRadius, shapePos.y + shapeRadius};
                DrawTriangle(p1, p2, p3, shapeColor);
                break;
            }
            case STAR: {
                for (int i = 0; i < 5; ++i) {
                    float angle1 = i * 72 * DEG2RAD;
                    float angle2 = ((i + 2) % 5) * 72 * DEG2RAD;
                    Vector2 p1 = {shapePos.x + cosf(angle1) * shapeRadius, shapePos.y + sinf(angle1) * shapeRadius};
                    Vector2 p2 = {shapePos.x + cosf(angle2) * shapeRadius, shapePos.y + sinf(angle2) * shapeRadius};
                    DrawLineV(p1, p2, shapeColor);
                }
                break;
            }
            case PENTAGON:
                DrawPoly(shapePos, 5, shapeRadius, 0, shapeColor);
                break;
        }

        DrawText("Double-click shape to change | Drag it | Use keyboard | Bounces & inertia active", 10, 10, 18, DARKGRAY);
        EndDrawing();
    }

    CloseWindow();
    return 0;
}
